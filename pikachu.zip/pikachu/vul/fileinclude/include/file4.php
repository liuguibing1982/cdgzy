<?php
$html.=<<<A
<img class=player src="include/tmac.png" />
<p class=nabname>
Tracy McGrady had seven all-star team, won the NBA scoring champion.On December 9, 2004 rockets home magic reversal the SAN Antonio spurs, McGrady in the final moments, had 13 points in 35 seconds, the game, go down in history forever.Incredible turnaround, plus 35 seconds 13 milestone!Since then the NBA with a new word, is called "t-mac moment".
</p>
A;
?>